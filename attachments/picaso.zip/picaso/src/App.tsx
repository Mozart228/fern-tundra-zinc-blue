import React from 'react';
import { Sidebar } from './components/Sidebar';
import { ChatDemo } from './components/ChatDemo';
import { PromptModal } from './components/PromptModal';
import { ProfileModal } from './components/ProfileModal';
import { VariablesModal } from './components/VariablesModal';
import { StatusBar } from './components/StatusBar';

function App() {
  return (
    <div className="h-screen w-screen flex flex-col overflow-hidden bg-gray-950 text-gray-200">
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <Sidebar />
        
        {/* Main Content - Chat Demo */}
        <ChatDemo />
      </div>
      
      {/* Status Bar */}
      <StatusBar />
      
      {/* Modals */}
      <PromptModal />
      <ProfileModal />
      <VariablesModal />
    </div>
  );
}

export default App;
