import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { AppState, Prompt, ContextProfile } from '../types';
import { defaultFolders, defaultProfiles, defaultPrompts } from '../data/defaults';

function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Initial state
      contextProfiles: defaultProfiles,
      activeProfileId: 'profile-1',
      prompts: defaultPrompts,
      folders: defaultFolders,
      searchQuery: '',
      activeFolderId: null,
      editingPrompt: null,
      editingProfile: null,
      isPromptModalOpen: false,
      isProfileModalOpen: false,
      isVariablesModalOpen: false,
      selectedPromptForInsert: null,
      variableValues: {},

      // Context Profile actions
      setActiveProfile: (id) => set({ activeProfileId: id }),
      
      addProfile: (profile) => set((state) => ({
        contextProfiles: [...state.contextProfiles, { ...profile, id: generateId(), createdAt: Date.now() }]
      })),
      
      updateProfile: (id, updates) => set((state) => ({
        contextProfiles: state.contextProfiles.map(p => p.id === id ? { ...p, ...updates } : p)
      })),
      
      deleteProfile: (id) => set((state) => ({
        contextProfiles: state.contextProfiles.filter(p => p.id !== id),
        activeProfileId: state.activeProfileId === id ? null : state.activeProfileId
      })),

      // Prompt actions
      addPrompt: (prompt) => set((state) => ({
        prompts: [...state.prompts, { ...prompt, id: generateId(), createdAt: Date.now() }]
      })),
      
      updatePrompt: (id, updates) => set((state) => ({
        prompts: state.prompts.map(p => p.id === id ? { ...p, ...updates } : p)
      })),
      
      deletePrompt: (id) => set((state) => ({
        prompts: state.prompts.filter(p => p.id !== id)
      })),

      // Folder actions
      addFolder: (folder) => set((state) => ({
        folders: [...state.folders, { ...folder, id: generateId() }]
      })),
      
      deleteFolder: (id) => set((state) => ({
        folders: state.folders.filter(f => f.id !== id),
        prompts: state.prompts.map(p => p.folder === id ? { ...p, folder: '' } : p),
        activeFolderId: state.activeFolderId === id ? null : state.activeFolderId
      })),

      // UI actions
      setSearchQuery: (query) => set({ searchQuery: query }),
      setActiveFolder: (id) => set({ activeFolderId: id }),
      
      openPromptModal: (prompt) => set({ 
        isPromptModalOpen: true, 
        editingPrompt: prompt || null 
      }),
      closePromptModal: () => set({ isPromptModalOpen: false, editingPrompt: null }),
      
      openProfileModal: (profile) => set({ 
        isProfileModalOpen: true, 
        editingProfile: profile || null 
      }),
      closeProfileModal: () => set({ isProfileModalOpen: false, editingProfile: null }),
      
      openVariablesModal: (prompt) => set({ 
        isVariablesModalOpen: true, 
        selectedPromptForInsert: prompt,
        variableValues: {}
      }),
      closeVariablesModal: () => set({ 
        isVariablesModalOpen: false, 
        selectedPromptForInsert: null,
        variableValues: {}
      }),
      
      setVariableValue: (key, value) => set((state) => ({
        variableValues: { ...state.variableValues, [key]: value }
      })),

      // Import/Export
      exportData: () => {
        const state = get();
        const data = {
          version: '1.0',
          exportedAt: new Date().toISOString(),
          contextProfiles: state.contextProfiles,
          prompts: state.prompts,
          folders: state.folders,
        };
        return JSON.stringify(data, null, 2);
      },
      
      importData: (json: string) => {
        try {
          const data = JSON.parse(json);
          if (!data.prompts || !data.contextProfiles || !data.folders) {
            return false;
          }
          set({
            prompts: data.prompts,
            contextProfiles: data.contextProfiles,
            folders: data.folders,
          });
          return true;
        } catch {
          return false;
        }
      },
    }),
    {
      name: 'contextflow-storage',
    }
  )
);

// Helper to extract variables from prompt text
export function extractVariables(text: string): string[] {
  const regex = /\{\{(\w+)\}\}/g;
  const variables = new Set<string>();
  let match;
  while ((match = regex.exec(text)) !== null) {
    variables.add(match[1]);
  }
  return Array.from(variables);
}

// Helper to substitute variables in text
export function substituteVariables(text: string, values: Record<string, string>): string {
  return text.replace(/\{\{(\w+)\}\}/g, (_, key) => values[key] || `{{${key}}}`);
}

// Helper to build final prompt
export function buildFinalPrompt(
  profileText: string | null,
  promptText: string,
  variableValues: Record<string, string>
): string {
  const resolvedPrompt = substituteVariables(promptText, variableValues);
  if (profileText) {
    return `${profileText}\n\n${resolvedPrompt}`;
  }
  return resolvedPrompt;
}
