export interface ContextProfile {
  id: string;
  name: string;
  text: string;
  createdAt: number;
}

export interface Prompt {
  id: string;
  name: string;
  folder: string;
  slug: string;
  text: string;
  tags: string[];
  createdAt: number;
}

export interface Folder {
  id: string;
  name: string;
  color: string;
}

export interface AppState {
  // Context Profiles
  contextProfiles: ContextProfile[];
  activeProfileId: string | null;
  
  // Prompts
  prompts: Prompt[];
  
  // Folders
  folders: Folder[];
  
  // UI State
  searchQuery: string;
  activeFolderId: string | null;
  editingPrompt: Prompt | null;
  editingProfile: ContextProfile | null;
  isPromptModalOpen: boolean;
  isProfileModalOpen: boolean;
  isVariablesModalOpen: boolean;
  selectedPromptForInsert: Prompt | null;
  variableValues: Record<string, string>;
  
  // Actions
  setActiveProfile: (id: string | null) => void;
  setSearchQuery: (query: string) => void;
  setActiveFolder: (id: string | null) => void;
  
  // Prompt actions
  addPrompt: (prompt: Omit<Prompt, 'id' | 'createdAt'>) => void;
  updatePrompt: (id: string, prompt: Partial<Prompt>) => void;
  deletePrompt: (id: string) => void;
  
  // Profile actions
  addProfile: (profile: Omit<ContextProfile, 'id' | 'createdAt'>) => void;
  updateProfile: (id: string, profile: Partial<ContextProfile>) => void;
  deleteProfile: (id: string) => void;
  
  // Folder actions
  addFolder: (folder: Omit<Folder, 'id'>) => void;
  deleteFolder: (id: string) => void;
  
  // UI actions
  openPromptModal: (prompt?: Prompt) => void;
  closePromptModal: () => void;
  openProfileModal: (profile?: ContextProfile) => void;
  closeProfileModal: () => void;
  openVariablesModal: (prompt: Prompt) => void;
  closeVariablesModal: () => void;
  setVariableValue: (key: string, value: string) => void;
  
  // Import/Export
  exportData: () => string;
  importData: (json: string) => boolean;
}
