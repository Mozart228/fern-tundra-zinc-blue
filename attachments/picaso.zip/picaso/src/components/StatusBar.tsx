import React from 'react';
import { Globe, CheckCircle2 } from 'lucide-react';

const platforms = [
  { name: 'DeepSeek', url: 'deepseek.com', color: '#4D6BFE' },
  { name: 'ChatGPT', url: 'chatgpt.com', color: '#10a37f' },
  { name: 'Qwen', url: 'chat.qwen.ai', color: '#6366f1' },
  { name: 'GigaChat', url: 'giga.chat', color: '#f59e0b' },
];

export const StatusBar: React.FC = () => {
  return (
    <div className="px-4 py-2 bg-gray-900/80 border-t border-gray-800 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <Globe className="w-3.5 h-3.5 text-gray-500" />
        <span className="text-[11px] text-gray-500">Поддерживаемые платформы:</span>
        <div className="flex items-center gap-2">
          {platforms.map(platform => (
            <span
              key={platform.name}
              className="flex items-center gap-1 text-[11px]"
              style={{ color: platform.color }}
            >
              <CheckCircle2 className="w-3 h-3" />
              {platform.name}
            </span>
          ))}
        </div>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-[11px] text-gray-600">ContextFlow MVP v1.0</span>
        <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
      </div>
    </div>
  );
};
