import React, { useState, useEffect } from 'react';
import { useStore } from '../store/useStore';
import { X, Save } from 'lucide-react';

export const ProfileModal: React.FC = () => {
  const { isProfileModalOpen, editingProfile, closeProfileModal, addProfile, updateProfile } = useStore();
  
  const [name, setName] = useState('');
  const [text, setText] = useState('');

  useEffect(() => {
    if (editingProfile) {
      setName(editingProfile.name);
      setText(editingProfile.text);
    } else {
      setName('');
      setText('');
    }
  }, [editingProfile, isProfileModalOpen]);

  if (!isProfileModalOpen) return null;

  const handleSave = () => {
    if (!name.trim() || !text.trim()) return;
    
    if (editingProfile) {
      updateProfile(editingProfile.id, { name: name.trim(), text: text.trim() });
    } else {
      addProfile({ name: name.trim(), text: text.trim() });
    }
    closeProfileModal();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 border border-gray-700 rounded-xl w-full max-w-lg shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-lg font-semibold text-white">
            {editingProfile ? 'Редактировать профиль' : 'Новый контекст-профиль'}
          </h2>
          <button onClick={closeProfileModal} className="p-1 text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 space-y-4">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Название *</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Например: Python-бэкенд"
              className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-sm text-gray-200 placeholder-gray-500 focus:border-blue-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-sm text-gray-400 mb-1">
              Системная инструкция *
              <span className="text-gray-600 text-xs ml-2">
                Будет добавлена перед каждым промптом
              </span>
            </label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Ты — senior Python-разработчик. Твой стек: FastAPI, PostgreSQL, Docker..."
              rows={10}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-sm text-gray-200 placeholder-gray-500 focus:border-blue-500 focus:outline-none resize-none"
            />
          </div>

          <div className="p-3 bg-gray-800/50 rounded-lg border border-gray-700">
            <p className="text-xs text-gray-500">
              💡 Контекст-профиль — это системная инструкция, которая автоматически подклеивается перед каждым промптом. 
              Используйте его для задания роли, стека технологий, правил проекта.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-2 p-4 border-t border-gray-700">
          <button
            onClick={closeProfileModal}
            className="px-4 py-2 text-sm text-gray-400 hover:text-white transition-colors"
          >
            Отмена
          </button>
          <button
            onClick={handleSave}
            disabled={!name.trim() || !text.trim()}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-700 disabled:text-gray-500 text-white text-sm font-medium rounded-lg transition-colors"
          >
            <Save className="w-4 h-4" />
            Сохранить
          </button>
        </div>
      </div>
    </div>
  );
};
