import React, { useState, useEffect } from 'react';
import { useStore } from '../store/useStore';
import { X, Save, HelpCircle } from 'lucide-react';

export const PromptModal: React.FC = () => {
  const { isPromptModalOpen, editingPrompt, folders, closePromptModal, addPrompt, updatePrompt } = useStore();
  
  const [name, setName] = useState('');
  const [folder, setFolder] = useState('');
  const [slug, setSlug] = useState('');
  const [text, setText] = useState('');
  const [tags, setTags] = useState('');

  useEffect(() => {
    if (editingPrompt) {
      setName(editingPrompt.name);
      setFolder(editingPrompt.folder);
      setSlug(editingPrompt.slug);
      setText(editingPrompt.text);
      setTags(editingPrompt.tags.join(', '));
    } else {
      setName('');
      setFolder('');
      setSlug('');
      setText('');
      setTags('');
    }
  }, [editingPrompt, isPromptModalOpen]);

  if (!isPromptModalOpen) return null;

  const handleSave = () => {
    if (!name.trim() || !text.trim()) return;
    
    const promptData = {
      name: name.trim(),
      folder,
      slug: slug.trim().toLowerCase().replace(/\s+/g, '-'),
      text: text.trim(),
      tags: tags.split(',').map(t => t.trim()).filter(Boolean),
    };

    if (editingPrompt) {
      updatePrompt(editingPrompt.id, promptData);
    } else {
      addPrompt(promptData);
    }
    closePromptModal();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 border border-gray-700 rounded-xl w-full max-w-lg shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-lg font-semibold text-white">
            {editingPrompt ? 'Редактировать промпт' : 'Новый промпт'}
          </h2>
          <button onClick={closePromptModal} className="p-1 text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 space-y-4">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Название *</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Например: Рефакторинг кода"
              className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-sm text-gray-200 placeholder-gray-500 focus:border-blue-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm text-gray-400 mb-1">Папка</label>
              <select
                value={folder}
                onChange={(e) => setFolder(e.target.value)}
                className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-sm text-gray-200 focus:border-blue-500 focus:outline-none"
              >
                <option value="">Без папки</option>
                {folders.map(f => (
                  <option key={f.id} value={f.id}>{f.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1">Слаг (быстрый вызов)</label>
              <input
                type="text"
                value={slug}
                onChange={(e) => setSlug(e.target.value)}
                placeholder="refactor"
                className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-sm text-gray-200 placeholder-gray-500 focus:border-blue-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm text-gray-400 mb-1">
              Текст промпта *
              <span className="text-gray-600 text-xs ml-2">
                Используйте {'{{'}переменная{'}'} для подстановки
              </span>
            </label>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Напиши тесты для {{код}} используя {{фреймворк}}..."
              rows={6}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-sm text-gray-200 placeholder-gray-500 focus:border-blue-500 focus:outline-none resize-none font-mono"
            />
            <div className="flex items-center gap-1 mt-1 text-xs text-gray-600">
              <HelpCircle className="w-3 h-3" />
              <span>Переменные вида {'{{'}имя{'}'} будут запрошены перед вставкой</span>
            </div>
          </div>

          <div>
            <label className="block text-sm text-gray-400 mb-1">Теги (через запятую)</label>
            <input
              type="text"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="код, рефакторинг, улучшение"
              className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-sm text-gray-200 placeholder-gray-500 focus:border-blue-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-2 p-4 border-t border-gray-700">
          <button
            onClick={closePromptModal}
            className="px-4 py-2 text-sm text-gray-400 hover:text-white transition-colors"
          >
            Отмена
          </button>
          <button
            onClick={handleSave}
            disabled={!name.trim() || !text.trim()}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-700 disabled:text-gray-500 text-white text-sm font-medium rounded-lg transition-colors"
          >
            <Save className="w-4 h-4" />
            Сохранить
          </button>
        </div>
      </div>
    </div>
  );
};
