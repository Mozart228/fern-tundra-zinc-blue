import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { 
  FolderOpen, Plus, Search, Download, Upload, Settings, 
  ChevronDown, Trash2, Edit3, FileText, Zap
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const {
    contextProfiles,
    activeProfileId,
    prompts,
    folders,
    searchQuery,
    activeFolderId,
    setActiveProfile,
    setSearchQuery,
    setActiveFolder,
    openPromptModal,
    openProfileModal,
    deletePrompt,
    deleteProfile,
    exportData,
    importData,
    addFolder,
    deleteFolder,
  } = useStore();

  const [showImport, setShowImport] = useState(false);
  const [showNewFolder, setShowNewFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [importText, setImportText] = useState('');
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [activeTab, setActiveTab] = useState<'prompts' | 'profiles'>('prompts');

  const filteredPrompts = prompts.filter(p => {
    const matchesSearch = !searchQuery || 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesFolder = !activeFolderId || p.folder === activeFolderId;
    return matchesSearch && matchesFolder;
  });

  const activeProfile = contextProfiles.find(p => p.id === activeProfileId);

  const handleExport = () => {
    const data = exportData();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'contextflow-backup.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = () => {
    const success = importData(importText);
    if (success) {
      setImportText('');
      setShowImport(false);
    } else {
      alert('Ошибка: неверный формат файла');
    }
  };

  const handleAddFolder = () => {
    if (newFolderName.trim()) {
      const colors = ['#3b82f6', '#10b981', '#8b5cf6', '#f59e0b', '#ef4444', '#ec4899'];
      addFolder({ name: newFolderName.trim(), color: colors[Math.floor(Math.random() * colors.length)] });
      setNewFolderName('');
      setShowNewFolder(false);
    }
  };

  return (
    <div className="w-80 bg-gray-900 border-r border-gray-700 flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-gray-700">
        <div className="flex items-center gap-2 mb-3">
          <Zap className="w-5 h-5 text-blue-400" />
          <h1 className="text-lg font-bold text-white">ContextFlow</h1>
        </div>
        
        {/* Context Profile Selector */}
        <div className="relative">
          <button
            onClick={() => setShowProfileDropdown(!showProfileDropdown)}
            className="w-full flex items-center justify-between px-3 py-2 bg-gray-800 rounded-lg border border-gray-600 text-sm text-gray-200 hover:border-blue-500 transition-colors"
          >
            <span className="truncate">
              {activeProfile ? `📋 ${activeProfile.name}` : '⚪ Без контекста'}
            </span>
            <ChevronDown className="w-4 h-4 text-gray-400" />
          </button>
          
          {showProfileDropdown && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-gray-800 border border-gray-600 rounded-lg shadow-xl z-50 max-h-48 overflow-y-auto">
              <button
                onClick={() => { setActiveProfile(null); setShowProfileDropdown(false); }}
                className={`w-full text-left px-3 py-2 text-sm hover:bg-gray-700 ${!activeProfileId ? 'text-blue-400' : 'text-gray-300'}`}
              >
                ⚪ Без контекста
              </button>
              {contextProfiles.map(profile => (
                <button
                  key={profile.id}
                  onClick={() => { setActiveProfile(profile.id); setShowProfileDropdown(false); }}
                  className={`w-full text-left px-3 py-2 text-sm hover:bg-gray-700 flex items-center justify-between ${profile.id === activeProfileId ? 'text-blue-400' : 'text-gray-300'}`}
                >
                  <span className="truncate">📋 {profile.name}</span>
                  <button
                    onClick={(e) => { e.stopPropagation(); openProfileModal(profile); }}
                    className="p-1 hover:text-white"
                  >
                    <Edit3 className="w-3 h-3" />
                  </button>
                </button>
              ))}
              <button
                onClick={() => { openProfileModal(); setShowProfileDropdown(false); }}
                className="w-full text-left px-3 py-2 text-sm text-blue-400 hover:bg-gray-700 flex items-center gap-1"
              >
                <Plus className="w-3 h-3" /> Новый профиль
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-700">
        <button
          onClick={() => setActiveTab('prompts')}
          className={`flex-1 px-4 py-2 text-sm font-medium ${activeTab === 'prompts' ? 'text-blue-400 border-b-2 border-blue-400' : 'text-gray-400 hover:text-gray-200'}`}
        >
          <FileText className="w-4 h-4 inline mr-1" />
          Промпты
        </button>
        <button
          onClick={() => setActiveTab('profiles')}
          className={`flex-1 px-4 py-2 text-sm font-medium ${activeTab === 'profiles' ? 'text-blue-400 border-b-2 border-blue-400' : 'text-gray-400 hover:text-gray-200'}`}
        >
          <Settings className="w-4 h-4 inline mr-1" />
          Профили
        </button>
      </div>

      {activeTab === 'prompts' ? (
        <>
          {/* Search */}
          <div className="p-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Поиск промптов..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-sm text-gray-200 placeholder-gray-500 focus:border-blue-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Folders */}
          <div className="px-3 pb-2">
            <div className="flex items-center gap-1 flex-wrap">
              <button
                onClick={() => setActiveFolder(null)}
                className={`px-2 py-1 text-xs rounded-md ${!activeFolderId ? 'bg-blue-600 text-white' : 'bg-gray-800 text-gray-400 hover:text-gray-200'}`}
              >
                Все
              </button>
              {folders.map(folder => (
                <button
                  key={folder.id}
                  onClick={() => setActiveFolder(folder.id)}
                  className={`px-2 py-1 text-xs rounded-md flex items-center gap-1 ${folder.id === activeFolderId ? 'text-white' : 'text-gray-400 hover:text-gray-200'}`}
                  style={{ backgroundColor: folder.id === activeFolderId ? folder.color : '#1f2937' }}
                >
                  {folder.name}
                  <button
                    onClick={(e) => { e.stopPropagation(); deleteFolder(folder.id); }}
                    className="hover:text-red-400 ml-0.5"
                  >
                    ×
                  </button>
                </button>
              ))}
              {showNewFolder ? (
                <div className="flex items-center gap-1">
                  <input
                    type="text"
                    value={newFolderName}
                    onChange={(e) => setNewFolderName(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddFolder()}
                    placeholder="Имя..."
                    className="px-2 py-1 text-xs bg-gray-800 border border-gray-600 rounded w-20 text-gray-200 focus:outline-none"
                    autoFocus
                  />
                  <button onClick={handleAddFolder} className="text-green-400 text-xs">✓</button>
                  <button onClick={() => setShowNewFolder(false)} className="text-red-400 text-xs">×</button>
                </div>
              ) : (
                <button
                  onClick={() => setShowNewFolder(true)}
                  className="px-2 py-1 text-xs text-gray-500 hover:text-gray-300"
                >
                  +
                </button>
              )}
            </div>
          </div>

          {/* Prompts List */}
          <div className="flex-1 overflow-y-auto px-3 pb-3">
            {filteredPrompts.map(prompt => {
              const folder = folders.find(f => f.id === prompt.folder);
              return (
                <div
                  key={prompt.id}
                  className="group p-3 mb-2 bg-gray-800 rounded-lg border border-gray-700 hover:border-gray-500 cursor-pointer transition-all"
                  onClick={() => openPromptModal(prompt)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm font-medium text-gray-200 truncate">{prompt.name}</h3>
                        {folder && (
                          <span className="px-1.5 py-0.5 text-[10px] rounded" style={{ backgroundColor: folder.color + '30', color: folder.color }}>
                            {folder.name}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-500 mt-1 truncate">{prompt.text.substring(0, 60)}...</p>
                      {prompt.tags.length > 0 && (
                        <div className="flex gap-1 mt-1.5 flex-wrap">
                          {prompt.tags.slice(0, 3).map(tag => (
                            <span key={tag} className="px-1.5 py-0.5 text-[10px] bg-gray-700 text-gray-400 rounded">
                              #{tag}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={(e) => { e.stopPropagation(); openPromptModal(prompt); }}
                        className="p-1 text-gray-400 hover:text-blue-400"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); deletePrompt(prompt.id); }}
                        className="p-1 text-gray-400 hover:text-red-400"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
            {filteredPrompts.length === 0 && (
              <div className="text-center py-8 text-gray-500 text-sm">
                Промпты не найдены
              </div>
            )}
          </div>

          {/* Add Prompt Button */}
          <div className="p-3 border-t border-gray-700">
            <button
              onClick={() => openPromptModal()}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors"
            >
              <Plus className="w-4 h-4" />
              Новый промпт
            </button>
          </div>
        </>
      ) : (
        /* Profiles Tab */
        <div className="flex-1 overflow-y-auto p-3">
          {contextProfiles.map(profile => (
            <div
              key={profile.id}
              className="group p-3 mb-2 bg-gray-800 rounded-lg border border-gray-700 hover:border-gray-500 cursor-pointer transition-all"
              onClick={() => openProfileModal(profile)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-medium text-gray-200 truncate">📋 {profile.name}</h3>
                  <p className="text-xs text-gray-500 mt-1 line-clamp-2">{profile.text.substring(0, 80)}...</p>
                </div>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={(e) => { e.stopPropagation(); openProfileModal(profile); }}
                    className="p-1 text-gray-400 hover:text-blue-400"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); deleteProfile(profile.id); }}
                    className="p-1 text-gray-400 hover:text-red-400"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
          <button
            onClick={() => openProfileModal()}
            className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 text-sm rounded-lg border border-gray-600 transition-colors mt-2"
          >
            <Plus className="w-4 h-4" />
            Новый профиль
          </button>
        </div>
      )}

      {/* Import/Export */}
      <div className="p-3 border-t border-gray-700">
        {showImport ? (
          <div className="space-y-2">
            <textarea
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
              placeholder='Вставьте JSON...'
              className="w-full h-24 px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-xs text-gray-200 placeholder-gray-500 focus:border-blue-500 focus:outline-none resize-none"
            />
            <div className="flex gap-2">
              <button onClick={handleImport} className="flex-1 px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs rounded transition-colors">
                Загрузить
              </button>
              <button onClick={() => setShowImport(false)} className="flex-1 px-3 py-1.5 bg-gray-700 hover:bg-gray-600 text-gray-300 text-xs rounded transition-colors">
                Отмена
              </button>
            </div>
          </div>
        ) : (
          <div className="flex gap-2">
            <button
              onClick={handleExport}
              className="flex-1 flex items-center justify-center gap-1 px-3 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs rounded-lg border border-gray-600 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              Экспорт
            </button>
            <button
              onClick={() => setShowImport(true)}
              className="flex-1 flex items-center justify-center gap-1 px-3 py-2 bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs rounded-lg border border-gray-600 transition-colors"
            >
              <Upload className="w-3.5 h-3.5" />
              Импорт
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
