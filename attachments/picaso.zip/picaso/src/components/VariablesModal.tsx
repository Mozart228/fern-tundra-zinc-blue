import React, { useState } from 'react';
import { useStore, extractVariables, substituteVariables, buildFinalPrompt } from '../store/useStore';
import { X, Check, Copy, ClipboardCheck } from 'lucide-react';

export const VariablesModal: React.FC = () => {
  const { 
    isVariablesModalOpen, 
    selectedPromptForInsert, 
    variableValues, 
    contextProfiles,
    activeProfileId,
    setVariableValue,
    closeVariablesModal 
  } = useStore();
  
  const [copied, setCopied] = useState(false);

  if (!isVariablesModalOpen || !selectedPromptForInsert) return null;

  const variables = extractVariables(selectedPromptForInsert.text);
  const activeProfile = contextProfiles.find(p => p.id === activeProfileId);
  
  const finalText = buildFinalPrompt(
    activeProfile?.text || null,
    selectedPromptForInsert.text,
    variableValues
  );

  const handleCopy = () => {
    navigator.clipboard.writeText(finalText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 border border-gray-700 rounded-xl w-full max-w-lg shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h2 className="text-lg font-semibold text-white">
            Заполните переменные
          </h2>
          <button onClick={closeVariablesModal} className="p-1 text-gray-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-4 space-y-4">
          {variables.length > 0 ? (
            <div className="space-y-3">
              {variables.map(variable => (
                <div key={variable}>
                  <label className="block text-sm text-gray-400 mb-1 capitalize">
                    {variable}
                  </label>
                  <input
                    type="text"
                    value={variableValues[variable] || ''}
                    onChange={(e) => setVariableValue(variable, e.target.value)}
                    placeholder={`Введите значение для ${variable}...`}
                    className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-lg text-sm text-gray-200 placeholder-gray-500 focus:border-blue-500 focus:outline-none"
                    autoFocus
                  />
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-400">Этот промпт не содержит переменных.</p>
          )}

          {/* Preview */}
          <div>
            <label className="block text-sm text-gray-400 mb-1">Предпросмотр результата:</label>
            <div className="p-3 bg-gray-800 border border-gray-600 rounded-lg text-xs text-gray-300 font-mono max-h-40 overflow-y-auto whitespace-pre-wrap">
              {finalText}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-2 p-4 border-t border-gray-700">
          <button
            onClick={closeVariablesModal}
            className="px-4 py-2 text-sm text-gray-400 hover:text-white transition-colors"
          >
            Отмена
          </button>
          <button
            onClick={handleCopy}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors"
          >
            {copied ? <ClipboardCheck className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Скопировано!' : 'Копировать'}
          </button>
        </div>
      </div>
    </div>
  );
};
