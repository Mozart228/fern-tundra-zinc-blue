import React, { useState } from 'react';
import { useStore, buildFinalPrompt } from '../store/useStore';
import { Eye, EyeOff, Copy, Check, FileText, Layers } from 'lucide-react';

export const PreviewPanel: React.FC = () => {
  const { contextProfiles, activeProfileId, prompts } = useStore();
  const [isExpanded, setIsExpanded] = useState(false);
  const [copied, setCopied] = useState(false);
  const [selectedPreviewPrompt, setSelectedPreviewPrompt] = useState<string | null>(null);

  const activeProfile = contextProfiles.find(p => p.id === activeProfileId);
  const previewPrompt = prompts.find(p => p.id === selectedPreviewPrompt);

  const handleCopy = () => {
    if (!previewPrompt) return;
    const text = buildFinalPrompt(activeProfile?.text || null, previewPrompt.text, {});
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={`border-t border-gray-800 bg-gray-900/50 transition-all duration-300 ${isExpanded ? 'h-48' : 'h-10'}`}>
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full h-10 px-4 flex items-center justify-between hover:bg-gray-800/50 transition-colors"
      >
        <div className="flex items-center gap-2">
          <Eye className="w-4 h-4 text-gray-400" />
          <span className="text-xs text-gray-400">Предпросмотр сборки промпта</span>
          {activeProfile && (
            <span className="px-1.5 py-0.5 text-[10px] bg-blue-900/30 text-blue-400 rounded">
              {activeProfile.name}
            </span>
          )}
        </div>
        <span className="text-xs text-gray-600">{isExpanded ? '▼' : '▲'}</span>
      </button>

      {isExpanded && (
        <div className="px-4 pb-3 animate-fade-in">
          <div className="flex gap-2 mb-2">
            <select
              value={selectedPreviewPrompt || ''}
              onChange={(e) => setSelectedPreviewPrompt(e.target.value)}
              className="flex-1 px-2 py-1.5 bg-gray-800 border border-gray-700 rounded text-xs text-gray-300 focus:outline-none focus:border-blue-500"
            >
              <option value="">Выберите промпт для предпросмотра...</option>
              {prompts.map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
            {previewPrompt && (
              <button
                onClick={handleCopy}
                className="px-2 py-1.5 bg-gray-800 border border-gray-700 rounded text-xs text-gray-400 hover:text-white transition-colors flex items-center gap-1"
              >
                {copied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                {copied ? 'OK' : 'Copy'}
              </button>
            )}
          </div>

          {previewPrompt ? (
            <div className="h-28 overflow-y-auto bg-gray-800/50 rounded-lg p-3 border border-gray-700">
              <div className="text-[11px] font-mono text-gray-400 whitespace-pre-wrap leading-relaxed">
                {activeProfile && (
                  <>
                    <span className="text-blue-400/60">/* Контекст-профиль: {activeProfile.name} */{'\n'}</span>
                    <span className="text-blue-400/80">{activeProfile.text}</span>
                    <span className="text-gray-600">{'\n\n---\n\n'}</span>
                  </>
                )}
                <span className="text-green-400/80">{previewPrompt.text}</span>
              </div>
            </div>
          ) : (
            <div className="h-28 flex items-center justify-center bg-gray-800/30 rounded-lg border border-gray-700/50">
              <p className="text-xs text-gray-600 flex items-center gap-2">
                <Layers className="w-4 h-4" />
                Выберите промпт для предпросмотра финальной сборки
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
