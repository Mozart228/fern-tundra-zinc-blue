import React, { useState } from 'react';
import { X, Zap, Keyboard, FolderOpen, Download, Lightbulb } from 'lucide-react';

export const InfoBanner: React.FC = () => {
  const [isVisible, setIsVisible] = useState(true);
  const [activeStep, setActiveStep] = useState(0);

  if (!isVisible) return null;

  const steps = [
    {
      icon: <Zap className="w-5 h-5 text-yellow-400" />,
      title: 'Быстрый вызов',
      description: 'Введите / в поле чата или нажмите Alt+P, чтобы открыть меню промптов',
    },
    {
      icon: <Keyboard className="w-5 h-5 text-blue-400" />,
      title: 'Навигация с клавиатуры',
      description: 'Используйте ↑↓ для выбора, Enter для вставки, Esc для закрытия',
    },
    {
      icon: <FolderOpen className="w-5 h-5 text-green-400" />,
      title: 'Контекст-профили',
      description: 'Выберите профиль в боковой панели — он автоматически подклеится к промпту',
    },
    {
      icon: <Download className="w-5 h-5 text-purple-400" />,
      title: 'Резервное копирование',
      description: 'Экспортируйте/импортируйте данные в JSON для переноса между устройствами',
    },
  ];

  return (
    <div className="absolute top-4 right-4 z-40 animate-fade-in">
      <div className="bg-gray-900/95 backdrop-blur-sm border border-gray-700 rounded-xl shadow-2xl w-80 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-3 border-b border-gray-700">
          <div className="flex items-center gap-2">
            <Lightbulb className="w-4 h-4 text-yellow-400" />
            <span className="text-sm font-medium text-white">Как пользоваться</span>
          </div>
          <button
            onClick={() => setIsVisible(false)}
            className="p-1 text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Steps */}
        <div className="p-3 space-y-2">
          {steps.map((step, index) => (
            <button
              key={index}
              onClick={() => setActiveStep(index)}
              className={`w-full text-left p-2.5 rounded-lg transition-all ${
                activeStep === index
                  ? 'bg-gray-800 border border-gray-600'
                  : 'hover:bg-gray-800/50'
              }`}
            >
              <div className="flex items-start gap-2.5">
                <div className="mt-0.5">{step.icon}</div>
                <div>
                  <h4 className="text-xs font-medium text-gray-200">{step.title}</h4>
                  {activeStep === index && (
                    <p className="text-xs text-gray-400 mt-1 animate-fade-in">
                      {step.description}
                    </p>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Footer */}
        <div className="px-3 pb-3">
          <button
            onClick={() => setIsVisible(false)}
            className="w-full px-3 py-2 bg-blue-600/20 hover:bg-blue-600/30 text-blue-400 text-xs font-medium rounded-lg transition-colors"
          >
            Понятно, начать работу →
          </button>
        </div>
      </div>
    </div>
  );
};
