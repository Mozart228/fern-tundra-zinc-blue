import React, { useState, useRef, useEffect } from 'react';
import { useStore, extractVariables, buildFinalPrompt } from '../store/useStore';
import { Send, Zap, Bot, User, Sparkles } from 'lucide-react';
import { InfoBanner } from './InfoBanner';
import { PreviewPanel } from './PreviewPanel';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export const ChatDemo: React.FC = () => {
  const {
    prompts,
    folders,
    contextProfiles,
    activeProfileId,
    openVariablesModal,
  } = useStore();

  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Привет! Я демонстрационный чат ContextFlow. Попробуйте ввести / в поле ввода, чтобы вызвать меню быстрых промптов. Также работает Alt+P.',
      timestamp: Date.now() - 60000,
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [showWidget, setShowWidget] = useState(false);
  const [widgetFilter, setWidgetFilter] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const widgetRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeProfile = contextProfiles.find(p => p.id === activeProfileId);

  const filteredPrompts = prompts.filter(p => {
    if (!widgetFilter) return true;
    return p.name.toLowerCase().includes(widgetFilter.toLowerCase()) ||
      p.slug.toLowerCase().includes(widgetFilter.toLowerCase()) ||
      p.tags.some(t => t.toLowerCase().includes(widgetFilter.toLowerCase()));
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [widgetFilter]);

  // Keyboard shortcut Alt+P
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.altKey && e.key === 'p') {
        e.preventDefault();
        setShowWidget(true);
        setWidgetFilter('');
        inputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;
    setInputValue(value);

    // Check for / trigger
    if (value === '/' || (value.endsWith(' /') && value.length > 1)) {
      setShowWidget(true);
      setWidgetFilter('');
      setSelectedIndex(0);
    } else if (showWidget) {
      // Extract filter after /
      const slashIndex = value.lastIndexOf('/');
      if (slashIndex >= 0) {
        const filter = value.substring(slashIndex + 1);
        setWidgetFilter(filter);
      } else {
        setShowWidget(false);
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (showWidget) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(prev => Math.min(prev + 1, filteredPrompts.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(prev => Math.max(prev - 1, 0));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        if (filteredPrompts[selectedIndex]) {
          selectPrompt(filteredPrompts[selectedIndex]);
        }
      } else if (e.key === 'Escape') {
        e.preventDefault();
        setShowWidget(false);
        setInputValue('');
      }
    } else if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const selectPrompt = (prompt: typeof prompts[0]) => {
    setShowWidget(false);
    setInputValue('');
    
    const variables = extractVariables(prompt.text);
    if (variables.length > 0) {
      openVariablesModal(prompt);
    } else {
      // Direct insert
      const finalText = buildFinalPrompt(
        activeProfile?.text || null,
        prompt.text,
        {}
      );
      setInputValue(finalText);
      inputRef.current?.focus();
    }
  };

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue.trim(),
      timestamp: Date.now(),
    };
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');

    // Simulate AI response
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: generateDemoResponse(inputValue.trim()),
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, aiMessage]);
    }, 1000);
  };

  const generateDemoResponse = (input: string): string => {
    const responses = [
      `Отличный запрос! Я обработал ваш промпт с учётом контекст-профиля${activeProfile ? ` "${activeProfile.name}"` : ''}. Вот что получилось:\n\nВ реальном использовании этот текст был бы отправлен в нейросеть (DeepSeek, ChatGPT, Qwen или GigaChat) с автоматически подклеенным системным контекстом.`,
      `Принято! Ваш запрос был собран с помощью ContextFlow. Контекст-профиль${activeProfile ? ` "${activeProfile.name}"` : ' не активен'}.\n\nВ демо-режиме я показываю, как работает вставка промптов. В реальном расширении текст автоматически вставится в поле чата нейросети.`,
      `✅ Промпт успешно вставлен! \n\nЭто демонстрация работы ContextFlow. В браузере расширение:\n1. Перехватывает ввод / в поле чата\n2. Показывает меню выбора промпта\n3. Запрашивает заполнение переменных\n4. Вставляет готовый текст с контекстом\n\nПопробуйте ввести / чтобы увидеть меню!`,
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-gray-950 relative">
      {/* Info Banner */}
      <InfoBanner />
      
      {/* Chat Header */}
      <div className="px-6 py-4 border-b border-gray-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-sm font-medium text-white">Демо-чат нейросети</h2>
            <p className="text-xs text-gray-500">
              {activeProfile ? `Контекст: ${activeProfile.name}` : 'Без контекста'} • Введите / для вызова промптов
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-2 py-1 bg-green-900/30 text-green-400 text-xs rounded-full flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse"></span>
            Online
          </span>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
        {messages.map(message => (
          <div
            key={message.id}
            className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {message.role === 'assistant' && (
              <div className="w-7 h-7 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                <Bot className="w-4 h-4 text-white" />
              </div>
            )}
            <div
              className={`max-w-[70%] px-4 py-3 rounded-2xl text-sm whitespace-pre-wrap ${
                message.role === 'user'
                  ? 'bg-blue-600 text-white rounded-tr-sm'
                  : 'bg-gray-800 text-gray-200 rounded-tl-sm'
              }`}
            >
              {message.content}
            </div>
            {message.role === 'user' && (
              <div className="w-7 h-7 bg-gray-700 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                <User className="w-4 h-4 text-gray-300" />
              </div>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Preview Panel */}
      <PreviewPanel />

      {/* Input Area */}
      <div className="px-6 py-4 border-t border-gray-800 relative">
        {/* Slash Widget */}
        {showWidget && (
          <div
            ref={widgetRef}
            className="absolute bottom-full left-6 right-6 mb-2 bg-gray-900 border border-gray-700 rounded-xl shadow-2xl overflow-hidden max-h-72 animate-slide-up"
          >
            <div className="p-2 border-b border-gray-700 flex items-center gap-2">
              <Zap className="w-4 h-4 text-yellow-400" />
              <span className="text-xs text-gray-400">Быстрые промпты</span>
              <span className="text-xs text-gray-600 ml-auto">↑↓ навигация • Enter выбор • Esc закрыть</span>
            </div>
            <div className="overflow-y-auto max-h-56">
              {filteredPrompts.length > 0 ? (
                filteredPrompts.map((prompt, index) => {
                  const folder = folders.find(f => f.id === prompt.folder);
                  return (
                    <button
                      key={prompt.id}
                      onClick={() => selectPrompt(prompt)}
                      className={`w-full text-left px-4 py-2.5 flex items-center gap-3 transition-colors ${
                        index === selectedIndex ? 'bg-blue-600/20 border-l-2 border-blue-500' : 'hover:bg-gray-800'
                      }`}
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-200 font-medium">{prompt.name}</span>
                          {prompt.slug && (
                            <span className="text-xs text-gray-500 font-mono">/{prompt.slug}</span>
                          )}
                        </div>
                        <p className="text-xs text-gray-500 truncate mt-0.5">{prompt.text.substring(0, 50)}...</p>
                      </div>
                      {folder && (
                        <span className="px-1.5 py-0.5 text-[10px] rounded flex-shrink-0" style={{ backgroundColor: folder.color + '30', color: folder.color }}>
                          {folder.name}
                        </span>
                      )}
                    </button>
                  );
                })
              ) : (
                <div className="px-4 py-6 text-center text-gray-500 text-sm">
                  Промпты не найдены
                </div>
              )}
            </div>
          </div>
        )}

        <div className="flex items-end gap-3">
          <div className="flex-1 relative">
            <textarea
              ref={inputRef}
              value={inputValue}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder="Введите сообщение или / для вызова промптов... (Alt+P)"
              rows={1}
              className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-sm text-gray-200 placeholder-gray-500 focus:border-blue-500 focus:outline-none resize-none"
              style={{ minHeight: '44px', maxHeight: '120px' }}
            />
          </div>
          <button
            onClick={handleSend}
            disabled={!inputValue.trim()}
            className="p-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-700 disabled:text-gray-500 text-white rounded-xl transition-colors"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
        
        <div className="flex items-center justify-between mt-2">
          <p className="text-xs text-gray-600">
            💡 Введите <kbd className="px-1 py-0.5 bg-gray-800 rounded text-gray-400">/</kbd> для вызова меню промптов или <kbd className="px-1 py-0.5 bg-gray-800 rounded text-gray-400">Alt+P</kbd>
          </p>
          <p className="text-xs text-gray-600">
            {inputValue.length > 0 && `${inputValue.length} символов`}
          </p>
        </div>
      </div>
    </div>
  );
};
